# Task Manager Web Application

This is a simple full-stack web application built using Node.js, Express.js, MySQL, and EJS. It allows users to create, view, update, and delete (CRUD) tasks in a styled browser interface.

## Features

- Add new tasks with a title and description
- View all saved tasks
- Edit task content and update status (Pending or Complete)
- Delete tasks
- Responsive front-end using semantic HTML and CSS
- Express.js server with multiple routes (/, /home)
- MySQL integration for persistent task storage
- Input validation and basic error handling

## Project Structure

project-folder/
│
├── public/
│   └── styles.css              # Main CSS styles
│
├── views/
│   ├── edit.ejs                # Task list view with forms
│   └── home.ejs                # Welcome page
│
├── server.js                   # Node.js + Express server
├── package.json                # Dependencies and scripts
├── .replit                     # Replit config file
└── README.md                   # Project documentation

## How to Install and Run

1. Clone or fork this repository.
2. Open the folder in Replit or a local development environment.
3. Install required packages by running:

   npm install

4. Start the server with:

   node server.js

5. Open your browser and visit:

   http://localhost:3000

   or use Replit’s Preview tab.

## Validation and Error Handling

- Client-side required field checks (title and description cannot be empty)
- Server-side validation to prevent invalid inserts
- Displays user-friendly messages for database or connection errors

## Technologies Used

- Node.js
- Express.js
- MySQL (with mysql2)
- EJS templating engine
- HTML5 and CSS3

## About This Project

This web application was developed for the Final Project in LIS 4613. It demonstrates all core requirements of the assignment rubric:

- Proper file organization
- Clean front-end with semantic HTML and CSS
- Express.js routing and server setup
- Full CRUD operations using MySQL
- Basic security practices with validation and error handling

