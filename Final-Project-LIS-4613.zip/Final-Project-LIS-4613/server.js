const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const PORT = 3000;

// MySQL connection
function getConnection() {
  return mysql.createConnection({
    host: 'sql5.freesqldatabase.com',
    user: 'sql5776962',
    password: 'wY9QSEi3eT',
    database: 'sql5776962',
    port: 3306
  });
}

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Routes
app.get('/', (req, res) => {
  const db = getConnection();
  db.query('SELECT * FROM tasks', (err, results) => {
    db.end();
    if (err) return res.send('Database error');
    res.render('edit', { tasks: results });
  });
});

app.post('/add', (req, res) => {
  const { title, description } = req.body;
  if (!title || !description) return res.send('All fields required.');

  const db = getConnection();
  db.query('INSERT INTO tasks (title, description) VALUES (?, ?)', [title, description], (err) => {
    db.end();
    if (err) return res.send('Insert failed');
    res.redirect('/');
  });
});

app.post('/update/:id', (req, res) => {
  const { id } = req.params;
  const { title, description, status } = req.body;
  if (!title || !description || !status) return res.send('All fields required.');

  const db = getConnection();
  db.query('UPDATE tasks SET title=?, description=?, status=? WHERE id=?', [title, description, status, id], (err) => {
    db.end();
    if (err) return res.send('Update failed');
    res.redirect('/');
  });
});

app.post('/delete/:id', (req, res) => {
  const { id } = req.params;

  const db = getConnection();
  db.query('DELETE FROM tasks WHERE id=?', [id], (err) => {
    db.end();
    if (err) return res.send('Delete failed');
    res.redirect('/');
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
